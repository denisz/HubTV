function SceneMain() {}

SceneMain.prototype.initialize = function() {
	alert("SceneMain.initialize()");
	this.settings = Settings.settings;
	this.showingInfo = false;
};

SceneMain.prototype.getUrl = function () {
	return 'http://' + this.settings.address + ':' + this.settings.port + "/file";
};

SceneMain.prototype.play = function(url) {
	alert("SceneMain.play()");
	$.sfScene.hide('Main');
	$.sfScene.show('Player', url);
	$.sfScene.focus('Player');
};

SceneMain.prototype.buildInfo = function(data) {

};

SceneMain.prototype.hideInfo = function() {
	alert("SceneMain.hideInfo()");
};

SceneMain.prototype.showMainKeyhelp = function() {
	$('#keyhelpMain').sfKeyHelp({
		'enter': 'Play',
		'red': 'Reload',
		'blue': 'Settings',
		'return': 'Return'
	});
};

SceneMain.prototype.showInfoKeyhelp = function() {
	$('#keyhelpMain').sfKeyHelp({
		'return': 'Return'
	});
};

SceneMain.prototype.reload = function() {

};

SceneMain.prototype.handleShow = function() {
	alert("SceneMain.handleShow()");
	this.showMainKeyhelp();
};

SceneMain.prototype.handleHide = function() {
	alert("SceneMain.handleHide()");
};

SceneMain.prototype.handleFocus = function() {
	alert("SceneMain.handleFocus()");
};

SceneMain.prototype.handleBlur = function() {
	alert("SceneMain.handleBlur()");
};

/**
 * KEY_UP: 			'onUp',
 KEY_DOWN: 			'onDown',
 KEY_LEFT: 			'onLeft',
 KEY_RIGHT: 			'onRight',
 KEY_ENTER:			'onSelect',
 KEY_RETURN:			'onReturn',
 KEY_STOP:			'onStop',
 KEY_FF: 			'onFF',
 KEY_RW:				'onRew',
 KEY_PLAY:			'onPlay',
 KEY_PAUSE:			'onPause',
 KEY_YELLOW:			'onYellow',
 KEY_RED:			'onRed',
 KEY_BLUE:			'onBlue',
 KEY_GREEN:			'onGreen',
 KEY_EXIT:			'onExit',
 KEY_MENU: 			'onMenu',
 KEY_BACK: 			'onReturn',
 KEY_SKIPFFORWARD: 	'onSkipForward',
 KEY_SKIPBACK: 		'onSkipBack',
 * @param keyCode
 */

SceneMain.prototype.handleKeyDown = function(keyCode) {
	switch ( keyCode ) {
		case $.sfKey.UP:
			break;
		case $.sfKey.DOWN:
			break;
		case $.sfKey.LEFT:
			break;
		case $.sfKey.RIGHT:
			break;
		case $.sfKey.ENTER:
			this.play(this.getUrl());
			break;
		case $.sfKey.INFO:
			break;
		case $.sfKey.RED:
			this.reload();
			break;
		case $.sfKey.FF:
			break;
		case $.sfKey.RW:
			break;
		case $.sfKey.BLUE:
			$.sfScene.hide('Main');
			$.sfScene.show('Settings');
			$.sfScene.focus('Settings');
			break;
	}

};